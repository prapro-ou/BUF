//
//背景のためのクラス
//

class ground{
    constructor({location, velocity, image}){//位置 速さ 画像
        this.loc = location
        this.img = new Image()
    }
    update () {} 
    draw () {}
}