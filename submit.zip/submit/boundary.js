//
//衝突マップ親クラス
//

class boudary {
    constructor({location}){//位置
        this.loc = location
    }
    update(){}
    draw(){}    
}