const get_coin = new Audio('../sound/get_coin.mp3');
const bgm = new Audio('../sound/BUF_opening_final_demo.wav');
bgm.volume = 0
const dissmiss_npc = new Audio('../sound/dismiss_npc.mp3')
const npc_speak = new Audio('../sound/npc_speak.mp3')
const next_conv = new Audio('../sound/ビープ音2.mp3')
const buy_item = new Audio('../sound/rezi.mp3')
const quiz_bgm = new Audio('../sound/BUF_quiz.wav') 
const shop_bgm = new Audio('../sound/BUF_douguya.wav')
const transition_bgm = new Audio('../sound/Short_mistery_005.mp3')
const endquiz_bgm = new Audio('../sound/jingle_24.mp3')
const entershop_bgm =  new Audio('../sound/Short_mistery_012.mp3')

const kusaQuiz_bgm = new Audio('../sound/kusa_bgm.mp3')
const boss_bgm = new Audio('../sound/RPG_Battle_04.mp3')
const end_bgm = new Audio('../sound/walk.mp3')
const walk_sound = new Audio('../sound/step.mp3')

const choose = new Audio('../sound/選択6.mp3')
const decide = new Audio('../sound/決定.mp3')